import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import {environment} from '../environments/environment';
let save_question_url = environment.url+'API/save_question';
@Injectable()
export class ServiceService {

  constructor(public http: HttpClient) { }

  handler(error) {
    return Observable.throw(error.json().error || 'server error');
  }

  save_questions(data,sub_qutiontion_array) {
    let body = new HttpParams()
      .set('data', JSON.stringify(data))
      .set('sub_question',JSON.stringify(sub_qutiontion_array));
    return this.http.post(save_question_url, body).catch(this.handler);

  }
}
