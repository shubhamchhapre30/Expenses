import { Component } from '@angular/core';
import {ServiceService} from '../app/service.service';
 declare const $:any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  total_questions: any = 0;
  questions: any = [];
  textboxes:any = [1,2,3,4,5];
  sub_questions:any=[];
  constructor(public service:ServiceService) {

  }

  add_new_question() {
    this.total_questions += 1;
    this.questions.push(this.total_questions);
    this.sub_questions.push([]);
  }

  chnage_tag(index, type) {
    let tag: any = document.getElementById(type + '_' + index);
    let add_sub_question:any = document.getElementById('add_sub_question_'+index);
    if(type != ''){
      if (tag.style.display == "block") {
        tag.style.display = "none";
      } else {
        tag.style.display = "block";
      }
      add_sub_question.style.display='block';
    }else{
      let textarea_tag: any = document.getElementById('textarea_' + index);
      textarea_tag.style.display = 'none';
      let textbox_tag: any = document.getElementById('textbox_' + index);
      textbox_tag.style.display = 'none';
      let textboxes_tag: any = document.getElementById('textboxes_' + index);
      textboxes_tag.style.display = 'none';

      add_sub_question.style.display='none';
      this.sub_questions[index-1].length=0;
    }

    if(type !='textarea'){
      let textarea_tag: any = document.getElementById('textarea_' + index);
      textarea_tag.style.display = 'none';
    }
    if(type !='textbox'){
      let textbox_tag: any = document.getElementById('textbox_' + index);
      textbox_tag.style.display = 'none';
    }
    if(type !='textboxes'){
      let textboxes_tag: any = document.getElementById('textboxes_' + index);
      textboxes_tag.style.display = 'none';
    }
  }

  add_sub_questions(index){
    let count =  this.sub_questions[index-1].length;
    this.sub_questions[index-1].push(count+1);
  }

  sub_chnage_tag(i,index,type){ console.log("1 "+i+ " 2 "+index+' type '+type);
    let tag: any = document.getElementById(type + '_'+i+'_' + index);
    if(type != ''){
      if (tag.style.display == "block") {
        tag.style.display = "none";
      } else {
        tag.style.display = "block";
      }
    }else{
      // let textarea_tag: any = document.getElementById('sub_textarea_' + index);
      // textarea_tag.style.display = 'none';
      let textbox_tag: any = document.getElementById('sub_textbox_'+i+'_' + index);
      textbox_tag.style.display = 'none';
      let textboxes_tag: any = document.getElementById('sub_textboxes_'+i+'_' + index);
      textboxes_tag.style.display = 'none';
    }
    console.log(type);
    // if(type !='sub_textarea'){
    //   let textarea_tag: any = document.getElementById('sub_textarea_' + index);
    //   textarea_tag.style.display = 'none';
    // }
    if(type !='sub_textbox'){
      let textbox_tag: any = document.getElementById('sub_textbox_'+i+'_' + index);
      textbox_tag.style.display = 'none';
    }
    if(type !='sub_textboxes'){
      let textboxes_tag: any = document.getElementById('sub_textboxes_'+i+'_' + index);
      textboxes_tag.style.display = 'none';
    }
  }

  save_questions(form){
    
    let data:any = [];
    let sub_question_array:any = [];
    this.questions.forEach(element => {
      data.push($('#add_question'+element).serializeArray());
      this.sub_questions[element-1].forEach(element1=>{
        sub_question_array.push($("#add_sub_question"+element+'_'+element1).serializeArray());
      })
      
    });
    console.log(sub_question_array);
    this.service.save_questions(data,sub_question_array).subscribe(
      info=>{
        console.log(info);
      }
    )
  }

}
